/*
###############################################################################
# If you use PhysiCell in your project, please cite PhysiCell and the version #
# number, such as below:                                                      #
#                                                                             #
# We implemented and solved the model using PhysiCell (Version x.y.z) [1].    #
#                                                                             #
# [1] A Ghaffarizadeh, R Heiland, SH Friedman, SM Mumenthaler, and P Macklin, #
#     PhysiCell: an Open Source Physics-Based Cell Simulator for Multicellu-  #
#     lar Systems, PLoS Comput. Biol. 14(2): e1005991, 2018                   #
#     DOI: 10.1371/journal.pcbi.1005991                                       #
#                                                                             #
# See VERSION.txt or call get_PhysiCell_version() to get the current version  #
#     x.y.z. Call display_citations() to get detailed information on all cite-#
#     able software used in your PhysiCell application.                       #
#                                                                             #
# Because PhysiCell extensively uses BioFVM, we suggest you also cite BioFVM  #
#     as below:                                                               #
#                                                                             #
# We implemented and solved the model using PhysiCell (Version x.y.z) [1],    #
# with BioFVM [2] to solve the transport equations.                           #
#                                                                             #
# [1] A Ghaffarizadeh, R Heiland, SH Friedman, SM Mumenthaler, and P Macklin, #
#     PhysiCell: an Open Source Physics-Based Cell Simulator for Multicellu-  #
#     lar Systems, PLoS Comput. Biol. 14(2): e1005991, 2018                   #
#     DOI: 10.1371/journal.pcbi.1005991                                       #
#                                                                             #
# [2] A Ghaffarizadeh, SH Friedman, and P Macklin, BioFVM: an efficient para- #
#     llelized diffusive transport solver for 3-D biological simulations,     #
#     Bioinformatics 32(8): 1256-8, 2016. DOI: 10.1093/bioinformatics/btv730  #
#                                                                             #
###############################################################################
#                                                                             #
# BSD 3-Clause License (see https://opensource.org/licenses/BSD-3-Clause)     #
#                                                                             #
# Copyright (c) 2015-2021, Paul Macklin and the PhysiCell Project             #
# All rights reserved.                                                        #
#                                                                             #
# Redistribution and use in source and binary forms, with or without          #
# modification, are permitted provided that the following conditions are met: #
#                                                                             #
# 1. Redistributions of source code must retain the above copyright notice,   #
# this list of conditions and the following disclaimer.                       #
#                                                                             #
# 2. Redistributions in binary form must reproduce the above copyright        #
# notice, this list of conditions and the following disclaimer in the         #
# documentation and/or other materials provided with the distribution.        #
#                                                                             #
# 3. Neither the name of the copyright holder nor the names of its            #
# contributors may be used to endorse or promote products derived from this   #
# software without specific prior written permission.                         #
#                                                                             #
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" #
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE   #
# IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE  #
# ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE   #
# LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR         #
# CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF        #
# SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS    #
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN     #
# CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)     #
# ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE  #
# POSSIBILITY OF SUCH DAMAGE.                                                 #
#                                                                             #
###############################################################################
*/

#include "./custom.h"

//probably usefull
#include <cmath>
#include <iostream>
#include <random>

Cell_Definition* cancer_cell;
Cell_Definition* stroma_cell;
Cell_Definition* TH_cell;
Cell_Definition* CTL_cell;

// Updated version
void create_cancer_cell_types( void )
{
	cancer_cell = find_cell_definition("cancer");

	// cell actions
	int virus_index = microenvironment.find_density_index("virus");
	cancer_cell->phenotype.secretion.uptake_rates[virus_index] = parameters.doubles("u_g");
	cancer_cell->phenotype.secretion.secretion_rates[virus_index] = 0.0;
	cancer_cell->phenotype.motility.migration_speed = 0.0;

	// set functions
	cancer_cell->functions.update_phenotype = cancer_cell_proliferation_infection_movement;
	cancer_cell->functions.custom_cell_rule = NULL;
	cancer_cell->functions.contact_function = NULL;
	cancer_cell->functions.update_migration_bias = NULL;
	return;
}
void create_stroma_cell_types( void )
{
	stroma_cell = find_cell_definition("stromal");

	// cell actions
	int virus_index = microenvironment.find_density_index("virus");
	stroma_cell->phenotype.secretion.uptake_rates[virus_index] = 	parameters.doubles("u_s");
	stroma_cell->phenotype.secretion.secretion_rates[virus_index] = 0.0;
	stroma_cell->phenotype.motility.migration_speed = 0.0;
	stroma_cell->phenotype.motility.is_motile = false;
	stroma_cell->phenotype.molecular.fraction_released_at_death[virus_index] = 0;

	// set functions
	stroma_cell->functions.update_phenotype = stroma_function;
	stroma_cell->functions.custom_cell_rule = NULL;
	stroma_cell->functions.contact_function = NULL;
	stroma_cell->functions.update_migration_bias = NULL;
	return;
}
void create_TH_cell_types( void )
{
	TH_cell = find_cell_definition("th");

	// cell actions
	int virus_index = microenvironment.find_density_index("virus");
	TH_cell->phenotype.secretion.uptake_rates[virus_index] = 0.0;
	TH_cell->phenotype.secretion.secretion_rates[virus_index] = 0.0;
	TH_cell->phenotype.motility.migration_speed = parameters.doubles("nu");

	// set functions
	TH_cell->functions.update_phenotype = TH_functions;
	TH_cell->functions.custom_cell_rule = NULL;
	TH_cell->functions.contact_function = NULL;
	TH_cell->functions.update_migration_bias = NULL;
	return;
}
void create_CTL_cell_types( void )
{
	CTL_cell = find_cell_definition("ctl");

	// cell actions
	int virus_index = microenvironment.find_density_index("virus");
	CTL_cell->phenotype.secretion.uptake_rates[virus_index] = 0.0;
	CTL_cell->phenotype.secretion.secretion_rates[virus_index] = 0.0;
	CTL_cell->phenotype.motility.migration_speed = parameters.doubles("nu");

	// set functions
	CTL_cell->functions.update_phenotype = CTL_functions;
	CTL_cell->functions.custom_cell_rule = NULL;
	CTL_cell->functions.contact_function = NULL;
	CTL_cell->functions.update_migration_bias = NULL;
	return;
}
void create_cell_types( void )
{
	// set the random seed
	SeedRandom( parameters.ints("random_seed") );

	initialize_default_cell_definition();
	cell_defaults.phenotype.secretion.sync_to_microenvironment( &microenvironment );

	cell_defaults.functions.volume_update_function = standard_volume_update_function;
	cell_defaults.functions.update_velocity = standard_update_cell_velocity;

	cell_defaults.functions.update_migration_bias = NULL;
	cell_defaults.functions.update_phenotype = update_cell_and_death_parameters_O2_based;
	cell_defaults.functions.custom_cell_rule = NULL;
	cell_defaults.functions.contact_function = NULL;

	cell_defaults.functions.add_cell_basement_membrane_interactions = NULL;
	cell_defaults.functions.calculate_distance_to_membrane = NULL;

	initialize_cell_definitions_from_pugixml();

	create_cancer_cell_types();
	create_stroma_cell_types();
	create_TH_cell_types();
	create_CTL_cell_types();

	build_cell_definitions_maps();
	setup_signal_behavior_dictionaries();

	cell_defaults.functions.update_phenotype = phenotype_function;
	cell_defaults.functions.custom_cell_rule = custom_function;
	cell_defaults.functions.contact_function = contact_function;

	//display_cell_definitions( std::cout );

	return;
}
void setup_microenvironment( void )
{
	// set domain parameters

	if( default_microenvironment_options.simulate_2D == false )
	{
		std::cout << "WARNING: overriding from 3-D to 2-D" << std::endl;
		default_microenvironment_options.simulate_2D = true;
	}

	initialize_microenvironment();

	static int virus_index = microenvironment.find_density_index("virus");
	static int wall_index = microenvironment.find_density_index("wall");
	static int chemokine_index = microenvironment.find_density_index("chemokine");

	for( int n = 0 ; n < microenvironment.mesh.voxels.size(); n++ )
	{
		std::vector<double> ECMdense = microenvironment.mesh.voxels[n].center;

		if( ECMdense[0]*ECMdense[0]+ECMdense[1]*ECMdense[1]>(parameters.doubles("R")+10)*(parameters.doubles("R")+10))
		{
			microenvironment(n)[virus_index] = 0;
			microenvironment(n)[wall_index] = 1;
			microenvironment(n)[chemokine_index] = 0;
		}
		else if(ECMdense[0]*ECMdense[0]+ECMdense[1]*ECMdense[1]>(parameters.doubles("R")-10)*(parameters.doubles("R")-10))
		{
			microenvironment(n)[virus_index] = 0;//parameters.doubles("initial_virus_density");
			microenvironment(n)[wall_index] = 3.5;
			microenvironment(n)[chemokine_index] = 0;
		}
		else if( ECMdense[0]*ECMdense[0]+ECMdense[1]*ECMdense[1]>250*250 )
		{
			microenvironment(n)[virus_index] = 0;
			microenvironment(n)[wall_index] = 5;
			microenvironment(n)[chemokine_index] = 0;

		}
		else
		{
			microenvironment(n)[virus_index] = 0;
			microenvironment(n)[wall_index] = 10;
			microenvironment(n)[chemokine_index] = 0;
		}
	}

	// location of virus
	double x_virus = 58;
	double y_virus = 17;
	double zone_radius = 20;


	for( int n = 0 ; n < microenvironment.mesh.voxels.size(); n++ )
	{
		std::vector<double> ECMdense = microenvironment.mesh.voxels[n].center;

		if( (x_virus-ECMdense[0])*(x_virus-ECMdense[0])+(y_virus-ECMdense[1])*(y_virus-ECMdense[1])<zone_radius*zone_radius)
		{
			microenvironment(n)[virus_index] = 7.12;
		}
	}
	printf("setup_microenvironment\t\t\n");
	return;
}
void setup_tissue( void ) //done
{
	double Xmin = microenvironment.mesh.bounding_box[0];
	double Ymin = microenvironment.mesh.bounding_box[1];
	double Zmin = microenvironment.mesh.bounding_box[2];

	double Xmax = microenvironment.mesh.bounding_box[3];
	double Ymax = microenvironment.mesh.bounding_box[4];
	double Zmax = microenvironment.mesh.bounding_box[5];

	if( default_microenvironment_options.simulate_2D == true )
	{
		Zmin = 0.0;
		Zmax = 0.0;
	}

	double Xrange = Xmax - Xmin;
	double Yrange = Ymax - Ymin;
	double Zrange = Zmax - Zmin;

	// // create some of each type of cell
	Cell* pC;

	for( int k=0; k < cell_definitions_by_index.size() ; k++ )
	{
		Cell_Definition* pCD = cell_definitions_by_index[k];
		//std::cout << "Placing cells of type " << pCD->name << " ... " << std::endl;
		for( int n = 0 ; n < parameters.ints("number_of_cells") ; n++ )
		{
			std::vector<double> position = {0,0,0};
			position[0] = Xmin + UniformRandom()*Xrange;
			position[1] = Ymin + UniformRandom()*Yrange;
			position[2] = Zmin + UniformRandom()*Zrange;

			pC = create_cell( *pCD );
			pC->assign_position( position );
		}
	}
	//std::cout << std::endl;

	// load cells from your CSV file (if enabled)
	load_cells_from_pugixml();

	return;
}

// functions to update
void cancer_cell_proliferation_infection_movement( Cell* pCell, Phenotype& phenotype, double dt )
{
	double R = parameters.doubles("R_cell_GBM");
	// double SA = 4*3.1416*R*R;
	double s = parameters.doubles("xhi");
	double pressure = 6*(1-1/(2*R)*s)*(1-1/(2*R)*s);
	double pressure_scale = 0.027288820670331;
	double max_pressure = pressure/pressure_scale;

	//tumour cell proliferation
	if(pCell->ID ==2)
	{
		int cycle_start_index = live.find_phase_index( PhysiCell_constants::live );
		int cycle_end_index = live.find_phase_index( PhysiCell_constants::live );

		pCell->phenotype.cycle.data.transition_rate( cycle_start_index , cycle_end_index ) = parameters.doubles("beta");

		if( pCell->state.simple_pressure*pCell->state.simple_pressure>max_pressure) // if cell under too much pressure -> no proliferation
		{pCell->phenotype.cycle.data.transition_rate( cycle_start_index , cycle_end_index ) = 0;}

	}

	// done until here
	cell_movement( pCell, phenotype, dt);
	infection_dynamics( pCell, phenotype, dt );

	return;

}
void cell_movement( Cell* pCell, Phenotype& phenotype, double dt )
{
	//cell movement
	static int wall_index = microenvironment.find_density_index("wall");
	double wall_amount = pCell->nearest_density_vector()[wall_index];

	static int persistence_time_index = pCell->custom_data.find_variable_index( "persistence_time" );
	static int cell_motility_type_index = pCell->custom_data.find_variable_index( "cell_motility_type" ); // unknown

	double persistence_time = pCell->custom_data.variables[persistence_time_index].value;
	double cell_motility_type = pCell->custom_data.variables[cell_motility_type_index].value; // 1 = go, 2 = stop

	std::vector<double> go_times_cumul(8);
	std::vector<double> persistence_times_vec(12);
	std::vector<double> speed_cumul(12);
	std::vector<double> speed_vec(12);
	go_times_cumul = go_times_cumulative();
	persistence_times_vec = persistance_distribution();
	speed_cumul = speed_cumulative();
	speed_vec = speed_distribution();

	if( wall_amount<2 & pCell->ID == 2 )
	{
		pCell->phenotype.motility.migration_speed = 0;
	}
	else if(pCell->ID != 2)
	{
		pCell->phenotype.motility.migration_speed = parameters.doubles("nu");
	}
	else
	{
		if( persistence_time <= PhysiCell_globals.current_time ) // if the cell's persistence time is up
		{
			// assign new type (stop = 2, or go = 1)
			double new_type_rand = UniformRandom();
			if(new_type_rand<=0.5)// GO
			{
				pCell->custom_data.variables[cell_motility_type_index].value = 1; // assign go type

				double speed_var = UniformRandom();

				for( int k=0; k<12; )
				{
					if( speed_var> speed_cumul[k] )
					{k++;}
					else
					{
						pCell->phenotype.motility.migration_speed = speed_vec[k]; // assign migration speed
						k = 12;
					}
				}
			}
			else
			{
				pCell->custom_data.variables[cell_motility_type_index].value = 2;
				pCell->phenotype.motility.migration_speed = 0;
			} // assign STOP type

			// assign persistence time - needs to be a real time!
			double go_stop_var = UniformRandom();
			for( int j=0; j<8; )
			{
				if( go_stop_var> go_times_cumul[j] )
				{j++;}
					else
				{
					pCell->custom_data.variables[persistence_time_index].value = persistence_times_vec[j]+PhysiCell_globals.current_time; // assign persist time
					j = 8;
				}
			}
		}

	}
	return;
}
void infection_dynamics( Cell* pCell, Phenotype& phenotype, double dt )
{

	//cell infection
	static int virus_signal_index = microenvironment.find_density_index( "virus");
	static int apoptosis_model_index =	pCell->phenotype.death.find_death_model_index( "apoptosis" );
	static double intracellular_virus_index = pCell->custom_data.find_variable_index( "intracellular_virus_amount" );

	double n = pCell->phenotype.molecular.internalized_total_substrates[virus_signal_index];//custom_data.variables[intracellular_virus_index].value;
	double p = pCell->nearest_density_vector()[virus_signal_index];
	double u = parameters.doubles("u_g");
	double Vvoxel = microenvironment.mesh.voxels[0].volume;//volume of voxel
	double nstar = parameters.doubles("m_half");//10;//infection threshol
	double alp = parameters.doubles("alpha");//1000;//virus burst number
	double gamma = parameters.doubles("gamma");
	double pmax = parameters.doubles("rho_max");//0.0125;

	// if( n>1)
	// {
	// }
	pCell->custom_data.variables[intracellular_virus_index].value = pCell->phenotype.molecular.internalized_total_substrates[virus_signal_index];

	if( pCell->phenotype.death.dead == false )// cell not dead
	{
		if(p<pmax)
		{pCell->phenotype.secretion.uptake_rates[virus_signal_index] = u*p/(n/Vvoxel+nstar/Vvoxel);}
		else
		{pCell->phenotype.secretion.uptake_rates[virus_signal_index] = u*pmax*pmax/(n/Vvoxel+nstar/Vvoxel)/p;}

		if( n > 1 && n <= alp) // update amount inside due to replication
		{
			pCell->phenotype.molecular.internalized_total_substrates[virus_signal_index] = n+dt*(gamma*n);
			pCell->custom_data.variables[intracellular_virus_index].value = pCell->phenotype.molecular.internalized_total_substrates[virus_signal_index];

		}
		else if( n > alp-1)
		{
			pCell->custom_data.variables[intracellular_virus_index].value = pCell->phenotype.molecular.internalized_total_substrates[virus_signal_index];
			pCell->phenotype.molecular.fraction_released_at_death[virus_signal_index] = 1;
			pCell->phenotype.secretion.uptake_rates[virus_signal_index] = 0;
			pCell->start_death( apoptosis_model_index );
		}
		else if( pCell->phenotype.molecular.internalized_total_substrates[virus_signal_index]<0 )
		{std::cout<<"Negative intracellular virus!! m_i = "<<pCell->phenotype.molecular.internalized_total_substrates[virus_signal_index]<<std::endl;}
	}
	if( pCell->phenotype.death.dead == true && pCell->phenotype.molecular.fraction_released_at_death[virus_signal_index]>0)
	{
		virus_induced_lysis(pCell, phenotype, dt );
	}
	return;
}
void virus_induced_lysis( Cell* pCell, Phenotype& phenotype, double dt )
{
	static int virus_signal_index = microenvironment.find_density_index( "virus");
	double pstar = pCell->phenotype.secretion.saturation_densities[virus_signal_index];
	double delta_V = parameters.doubles("delta_V");//0.1466;
	double Vvoxel = microenvironment.mesh.voxels[0].volume;//volume of voxel
	double p = pCell->nearest_density_vector()[virus_signal_index];
	double n = pCell->phenotype.molecular.internalized_total_substrates[virus_signal_index];

	if( pCell->phenotype.molecular.internalized_total_substrates[virus_signal_index]> 1 )
	{
			double amount_to_add = (n-n*exp(-delta_V*dt))/Vvoxel;
			if( amount_to_add > pstar-p )
			{
				pCell->nearest_density_vector()[virus_signal_index] += (pstar-p)*dt;
				pCell->phenotype.molecular.internalized_total_substrates[virus_signal_index] -= (pstar-p)*Vvoxel*dt;
			}
			else
			{
				pCell->nearest_density_vector()[virus_signal_index] += (amount_to_add)*dt;
				pCell->phenotype.molecular.internalized_total_substrates[virus_signal_index] = n*exp(-delta_V*dt);
			}
	}

	return;
}
void stroma_function( Cell* pCell, Phenotype& phenotype, double dt )
{
	static int virus_signal_index = microenvironment.find_density_index("virus");
	static double intracellular_virus_index = pCell->custom_data.find_variable_index( "intracellular_virus_amount" );
	pCell->custom_data.variables[intracellular_virus_index].value = pCell->phenotype.molecular.internalized_total_substrates[virus_signal_index];
	if(pCell->phenotype.molecular.internalized_total_substrates[virus_signal_index]>1e5)
	{
		pCell->phenotype.molecular.internalized_total_substrates[virus_signal_index] = 0;
		pCell->custom_data.variables[intracellular_virus_index].value = 0;
	}
	else
	{
		pCell->custom_data.variables[intracellular_virus_index].value = pCell->phenotype.molecular.internalized_total_substrates[virus_signal_index];
	}

	return;
}
void TH_functions( Cell* pCell, Phenotype& phenotype, double dt )
{

	static int wall_index = microenvironment.find_density_index( "wall" );
	double wall_amount = pCell->nearest_density_vector()[wall_index];

	std::vector<double> ae_ini(3);

	if( wall_amount<2 )// Make TH cells that have left the diameter of the tumour turn around
	{

		pCell->phenotype.motility.migration_speed = parameters.doubles("nu");
		ae_ini = -1*pCell->position;
		pCell->phenotype.motility.migration_bias = 1;
		normalize( &( ae_ini ) );
		pCell->phenotype.motility.migration_bias_direction = ae_ini;

	}
	else
	{
		pCell->phenotype.motility.migration_speed = parameters.doubles("nu");
		pCell->phenotype.motility.migration_bias = 0;
	}

	// TH secretion of cytokines
	std::vector<Cell*> nearby = pCell->cells_in_my_container();

	static int virus_signal_index = microenvironment.find_density_index( "virus");
	static int chemokine_index = microenvironment.find_density_index( "chemokine");

	int cycle_start_index = Ki67_basic.find_phase_index( PhysiCell_constants::Ki67_negative );
	int cycle_end_index = Ki67_basic.find_phase_index( PhysiCell_constants::Ki67_positive );

	Cell* pC = NULL;
	bool stop = false;
	int i=0;

	double nstar = parameters.doubles("m_half");

	while( !stop && i < nearby.size() )
	{
		pC = nearby[i];
		if( pC->phenotype.molecular.internalized_total_substrates[virus_signal_index] > nstar &&
			pC->phenotype.death.dead == false &&
			pC != pCell && pC->ID != 4)
			{ stop = true; }

		i++;

		if( stop == false )
			{ pC = NULL; }
	}

	if( pC )
	{
		pCell->phenotype.secretion.secretion_rates[chemokine_index] = parameters.doubles("S_chemokine_CD4");//0.0417;//0.1;
		pCell->phenotype.cycle.data.transition_rate(cycle_start_index,cycle_end_index) = parameters.doubles("r_01_CD4")*parameters.doubles("TH_prolif_increase_due_to_stimulus");
		pCell->phenotype.motility.migration_speed = 0.1;
	}
	else
	{
		pCell->phenotype.secretion.secretion_rates[chemokine_index] = 0;//0.1;
		pCell->phenotype.cycle.data.transition_rate(cycle_start_index,cycle_end_index) = parameters.doubles("r_01_CD4");
	}
	return;
}
void CTL_functions( Cell* pCell, Phenotype& phenotype, double dt )
{

	int cycle_start_index = Ki67_basic.find_phase_index( PhysiCell_constants::Ki67_negative );
	int cycle_end_index = Ki67_basic.find_phase_index( PhysiCell_constants::Ki67_positive );

	if( phenotype.death.dead == true )
	{
		pCell->functions.update_phenotype = NULL;
		return;
	}

	static int attach_lifetime_i = pCell->custom_data.find_variable_index( "attachment lifetime" );

	if( pCell->state.neighbors.size() > 0 )
	{
		extra_elastic_attachment_mechanics( pCell, phenotype, dt );
		bool detach_me = false;

		if( immune_cell_attempt_apoptosis( pCell, pCell->state.neighbors[0], dt ) )
		{
			immune_cell_trigger_apoptosis( pCell, pCell->state.neighbors[0] );
			detach_me = true;
		}

		if( detach_me )
		{

			detach_cells( pCell, pCell->state.neighbors[0] );
			phenotype.motility.is_motile = true;
			CTL_movement( pCell, phenotype, dt);
			pCell->phenotype.cycle.data.transition_rate(cycle_start_index,cycle_end_index) = parameters.doubles("r_01_CD8")*parameters.doubles("CTL_prolif_increase_due_to_stimulus");
		}
		return;
	}

	if( immune_cell_check_neighbors_for_attachment( pCell , dt) )
	{
		phenotype.motility.is_motile = false;
		return;
	}

	phenotype.motility.is_motile = true;
	CTL_movement( pCell, phenotype, dt);

	return;
}
void extra_elastic_attachment_mechanics( Cell* pCell, Phenotype& phenotype, double dt )
{
	for( int i=0; i < pCell->state.neighbors.size() ; i++ )
	{
		add_elastic_velocity( pCell, pCell->state.neighbors[i], pCell->custom_data["elastic coefficient"] );
	}

	return;
}
void add_elastic_velocity( Cell* pActingOn, Cell* pAttachedTo , double elastic_constant )
{
	std::vector<double> displacement = pAttachedTo->position - pActingOn->position;
	axpy( &(pActingOn->velocity) , elastic_constant , displacement );

	return;
}
Cell* immune_cell_check_neighbors_for_attachment( Cell* pAttacker , double dt )
{
	std::vector<Cell*> nearby = pAttacker->cells_in_my_container();
	int i = 0;
	while( i < nearby.size() )
	{
		// don't try to kill yourself
		if( nearby[i] != pAttacker )
		{
			if( immune_cell_attempt_attachment( pAttacker, nearby[i] , dt ) )
			{ return nearby[i]; }
		}
		i++;
	}

	return NULL;
}
bool immune_cell_attempt_attachment( Cell* pAttacker, Cell* pTarget , double dt )
{
	static double max_attachment_distance = parameters.doubles("d_attach"); // 18.0;

	static int virus_signal_index = microenvironment.find_density_index( "virus");
	double internal_virus = pTarget->phenotype.molecular.internalized_total_substrates[virus_signal_index];//custom_data.variables[intracellular_virus_index].value;

	static int attach_lifetime_i = pAttacker->custom_data.find_variable_index( "attachment lifetime" );

	double kill_time = parameters.doubles("tau"); // how long the cell needs to attach for  the infected cell to be killed
	double nstar = parameters.doubles("m_half"); // how long the cell needs to attach for  the infected cell to be killed

	if( internal_virus > nstar && pTarget->phenotype.death.dead == false && pTarget->ID!=4)
	{
		std::vector<double> displacement = pTarget->position - pAttacker->position;
		double distance_scale = norm( displacement );
		if( distance_scale > max_attachment_distance )
		{ return false; }

		attach_cells( pAttacker, pTarget );
		pAttacker->custom_data[attach_lifetime_i] = PhysiCell_globals.current_time + kill_time;

		return true;
	}

	return false;
}
void CTL_movement( Cell* pCell, Phenotype& phenotype, double dt )
{
	static int wall_index = microenvironment.find_density_index( "wall" );
	double wall_amount = pCell->nearest_density_vector()[wall_index];

	static int chemokine_index = microenvironment.find_density_index( "chemokine" );
	double chemokine_amount = pCell->nearest_density_vector()[chemokine_index];

	int cycle_start_index = Ki67_basic.find_phase_index( PhysiCell_constants::Ki67_negative );
	int cycle_end_index = Ki67_basic.find_phase_index( PhysiCell_constants::Ki67_positive );


	std::vector<double> ae_ini(3);

	// TH movement
	if( wall_amount<2 )
	{
		std::cout<<"outside domain "<<pCell->phenotype.motility.migration_speed<<std::endl;
		pCell->phenotype.motility.migration_bias = 1;
		pCell->phenotype.motility.migration_bias_direction = pCell->nearest_gradient(wall_index);
		ae_ini = -1*pCell->position;

		pCell->phenotype.motility.migration_bias = 1;
		normalize( &( ae_ini ) );
		pCell->phenotype.motility.migration_bias_direction = ae_ini;

		return;
	}
	else if(chemokine_amount>1e-8)// sample chemotaxis gradient and random walk in that direction
	{
		pCell->phenotype.motility.migration_speed = parameters.doubles("nu")+(parameters.doubles("nu_max")-parameters.doubles("nu"))*(chemokine_amount/(parameters.doubles("nu_star")+chemokine_amount));
		pCell->phenotype.motility.migration_bias = parameters.doubles("b_CD8");//0.85;
		pCell->phenotype.motility.migration_bias_direction = pCell->nearest_gradient(chemokine_index);
		pCell->phenotype.cycle.data.transition_rate(cycle_start_index,cycle_end_index) = parameters.doubles("r_01_CD8");

		return;
	}
	else if(chemokine_amount>1e-3)
	{
		pCell->phenotype.cycle.data.transition_rate(cycle_start_index,cycle_end_index) = parameters.doubles("r_01_CD8")*parameters.doubles("CTL_prolif_increase_due_to_stimulus");//7.9026*1e-5*1e1;
		pCell->phenotype.motility.migration_speed = parameters.doubles("nu")+(parameters.doubles("nu_max")-parameters.doubles("nu"))*(chemokine_amount/(parameters.doubles("nu_star")+chemokine_amount));
		pCell->phenotype.motility.migration_bias = parameters.doubles("b_CD8");
		pCell->phenotype.motility.migration_bias_direction = pCell->nearest_gradient(chemokine_index);

		return;
	}
	else
	{
		pCell->phenotype.motility.migration_bias = 0;
		pCell->phenotype.motility.migration_speed = parameters.doubles("nu");
		pCell->phenotype.cycle.data.transition_rate(cycle_start_index,cycle_end_index) = parameters.doubles("r_01_CD8");

		return;
	}
}
bool immune_cell_attempt_apoptosis( Cell* pAttacker, Cell* pTarget, double dt )
{
	static int apoptosis_model_index = pTarget->phenotype.death.find_death_model_index( "apoptosis" );
	static int attach_lifetime_i = pAttacker->custom_data.find_variable_index( "attachment lifetime" );

	// CTL kills cell if it has been attached for enough time
	if( pAttacker->custom_data[attach_lifetime_i] < PhysiCell_globals.current_time )
	{
		return true;
	}
	return false;
}
bool immune_cell_trigger_apoptosis( Cell* pAttacker, Cell* pTarget )
{
	static int apoptosis_model_index = pTarget->phenotype.death.find_death_model_index( "apoptosis" );

	static int virus_index = microenvironment.find_density_index( "virus" );

	// if the Target cell is already dead, don't bother!
	if( pTarget->phenotype.death.dead == true )
	{ return false; }

	pTarget->start_death( apoptosis_model_index );
	pTarget->phenotype.molecular.fraction_released_at_death[virus_index] = 0;//1;
	return true;
}


// Custom distribution
std::vector<double> go_times_cumulative()
{
	// setting up distributions for movement and persistance of cells
	std::vector<double> go_times_cumul(8);
  go_times_cumul[0] = 0.01;
	go_times_cumul[1] = 0.962;
	go_times_cumul[2] = 0.9735;
	go_times_cumul[3] = 0.9835;
	go_times_cumul[4] = 0.9935;
	go_times_cumul[5] = 0.9955;
	go_times_cumul[6] = 0.9975;
	go_times_cumul[7] = 1;

	return go_times_cumul;
}

std::vector<double> persistance_distribution()
{
	std::vector<double> persistance_times_vec(8);
  persistance_times_vec[0] = 0;
	persistance_times_vec[1] = 30;
	persistance_times_vec[2] = 60;
	persistance_times_vec[3] = 90;
	persistance_times_vec[4] = 120;
	persistance_times_vec[5] = 150;
	persistance_times_vec[6] = 180;
	persistance_times_vec[7] = 240;

	return  persistance_times_vec;
}

std::vector<double> speed_cumulative()
{
	std::vector<double> speed_cumul(12);
  speed_cumul[0] = 0.0014;
	speed_cumul[1] = 0.0317;
	speed_cumul[2] = 0.2441;
	speed_cumul[3] = 0.5137;
	speed_cumul[4] = 0.7598;
	speed_cumul[5] = 0.8822;
	speed_cumul[6] = 0.9453;
	speed_cumul[7] = 0.9787;
	speed_cumul[8] = 0.9882;
	speed_cumul[9] = 0.9937;
	speed_cumul[10] = 0.9963;
	speed_cumul[11] = 1;

	return speed_cumul;
}
std::vector<double> speed_distribution()
{
	std::vector<double> speed_vec(12);
  speed_vec[0] = 0.0833;
	speed_vec[1] = 0.1667;
	speed_vec[2] = 0.25;
	speed_vec[3] = 0.333;
	speed_vec[4] = 0.4167;
	speed_vec[5] = 0.5;
	speed_vec[6] = 0.5833;
	speed_vec[7] = 0.667;
	speed_vec[8] = 0.75;
	speed_vec[9] = 0.833;
	speed_vec[10] = 0.9167;
	speed_vec[11] = 1;

	return speed_vec;
}





// Coloring functions
std::vector<std::string> my_coloring_function( Cell* pCell )
{ return paint_by_number_cell_coloring(pCell); }

void phenotype_function( Cell* pCell, Phenotype& phenotype, double dt )
{ return; }

void custom_function( Cell* pCell, Phenotype& phenotype , double dt )
{ return; }

void contact_function( Cell* pMe, Phenotype& phenoMe , Cell* pOther, Phenotype& phenoOther , double dt )
{ return; }
